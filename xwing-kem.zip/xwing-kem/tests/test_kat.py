"""Known-Answer-Test (KAT) validation against the official X-Wing vectors.

WHAT THIS VALIDATES, AND THE HONEST LIMIT
-----------------------------------------
The X-Wing draft ships deterministic vectors: a fixed 32-byte seed expands to
the key material, and fixed encapsulation coins produce a fixed ciphertext and
shared secret. There are therefore THREE things we can attempt to validate,
each with different backend requirements:

  (A) KEYGEN from seed  -> the X-Wing public key bytes.
        liboqs-python (>=0.14.0) exposes derandomized generate_keypair_seed(),
        so this CAN run -- once the SHAKE seed-expansion split is confirmed
        against the reference xwing.py (see the guard in the test).

  (B) ENCAPS from coins -> ciphertext + shared secret.
        Neither liboqs-python nor pyca/cryptography exposes a *seeded*
        encapsulation, so this half can only run against a derandomized
        reference implementation supplied via XWING_REF_ENCAPS.

  (C) COMBINER against intermediate components -> shared secret.
        Pure SHA3-256 over known inputs; runs EVERYWHERE with no backend, if
        the vector file includes the intermediate secrets.

Every part SKIPS independently with an explanatory message rather than passing
falsely. A skip is honest; a silently-green self-test would not be.

VECTOR FILE (`tests/xwing_kat.json`), all values hex-encoded:
    {
      "seed":        "<32 bytes>",     # X-Wing KeyGen seed
      "expected_pk": "<1216 bytes>",   # pk_M (1184) || pk_X (32)
      "eseed":       "<64 bytes>",     # Encaps coins
      "expected_ct": "<1120 bytes>",   # ct_M (1088) || ct_X (32)
      "expected_ss": "<32 bytes>",     # shared secret
      # Optional, enables the backend-free combiner KAT (C):
      "ss_m": "<32>", "ss_x": "<32>", "ct_x": "<32>", "pk_x": "<32>"
    }

Obtain vectors from github.com/dconnolly/draft-connolly-cfrg-xwing-kem or a
trusted reference implementation. Do not hand-edit them.
"""

from __future__ import annotations

import hashlib
import json
import os

import pytest

from xwing_kem._core import _combiner

HERE = os.path.dirname(__file__)
KAT_PATH = os.path.join(HERE, "xwing_kat.json")


def _load_vectors():
    if not os.path.exists(KAT_PATH):
        pytest.skip(
            f"No official X-Wing KAT file at {KAT_PATH}. "
            "Add tests/xwing_kat.json from the draft reference to enable "
            "spec-conformance validation. Until then this package is "
            "UNVALIDATED against official vectors (see KNOWN-GAPS.md)."
        )
    with open(KAT_PATH) as fh:
        raw = json.load(fh)
    return {k: bytes.fromhex(v) for k, v in raw.items()}


def _require_liboqs():
    try:
        import oqs  # noqa: F401
        return oqs
    except Exception:
        pytest.skip(
            "Keygen KAT requires liboqs-python (>=0.14.0), which exposes "
            'derandomized generate_keypair_seed(). Install with: '
            'pip install "xwing-kem[liboqs]".'
        )


# Set to True only after you have checked the SHAKE-256 seed-expansion split
# in _xwing_keygen_from_seed() byte-for-byte against the draft's reference
# xwing.py (Appendix B). Leaving it False keeps the keygen KAT in a safe SKIP
# rather than asserting on an unconfirmed expansion.
_SEED_EXPANSION_CONFIRMED = False


def _xwing_keygen_from_seed(oqs, seed: bytes) -> bytes:
    """Deterministically derive the X-Wing public key from the 32-byte seed.

    Per the draft's key derivation, the seed is expanded with SHAKE-256 into
    the ML-KEM-768 keygen randomness and the 32-byte X25519 private scalar.
    Returns the X-Wing public key (pk_M || pk_X).

    WARNING: the exact byte split below is a best-effort reconstruction and
    MUST be confirmed against the reference xwing.py before being trusted.
    """
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey

    expanded = hashlib.shake_256(seed).digest(64 + 32)
    mlkem_seed = expanded[:64]          # ML-KEM derand seed (d || z)
    x25519_sk_bytes = expanded[64:96]   # X25519 scalar

    with oqs.KeyEncapsulation("ML-KEM-768") as kem:
        mlkem_pk = kem.generate_keypair_seed(mlkem_seed)

    x25519_sk = X25519PrivateKey.from_private_bytes(x25519_sk_bytes)
    x25519_pk = x25519_sk.public_key().public_bytes_raw()
    return mlkem_pk + x25519_pk


# --------------------------------------------------------------------------- #
# (A) KEYGEN-from-seed KAT
# --------------------------------------------------------------------------- #
def test_kat_keygen_public_key():
    vectors = _load_vectors()
    oqs = _require_liboqs()

    if not _SEED_EXPANSION_CONFIRMED:
        pytest.skip(
            "Keygen KAT is wired for liboqs, but the SHAKE-256 seed-expansion "
            "split in _xwing_keygen_from_seed() has not been confirmed against "
            "the draft reference xwing.py. Confirm it, set "
            "_SEED_EXPANSION_CONFIRMED = True, and this test will assert "
            "derived_pk == expected_pk."
        )

    derived_pk = _xwing_keygen_from_seed(oqs, vectors["seed"])
    assert derived_pk == vectors["expected_pk"], (
        "X-Wing public key derived from seed does not match the KAT vector"
    )


# --------------------------------------------------------------------------- #
# (B) ENCAPS-from-coins KAT  -- needs a derandomized reference encaps
# --------------------------------------------------------------------------- #
def test_kat_encaps_shared_secret():
    _load_vectors()
    if not os.environ.get("XWING_REF_ENCAPS"):
        pytest.skip(
            "Encaps KAT requires a derandomized reference encapsulation. "
            "Neither liboqs-python nor pyca/cryptography exposes seeded "
            "encapsulation, so this half cannot run on those backends. Point "
            "XWING_REF_ENCAPS at the draft reference xwing.py to enable it. "
            "The combiner itself is independently tested in "
            "test_xwing.py::test_combiner_omits_mlkem_ciphertext."
        )
    raise NotImplementedError(
        "Bind XWING_REF_ENCAPS to the reference encaps, derive (ss_M, ss_X, "
        "ct_X, pk_X) from vectors['eseed'] + vectors['expected_pk'], then "
        "assert ct == expected_ct and _combiner(...) == expected_ss."
    )


# --------------------------------------------------------------------------- #
# (C) COMBINER KAT  -- ALWAYS runnable, no backend needed
# --------------------------------------------------------------------------- #
def test_kat_combiner_against_vector_components():
    vectors = _load_vectors()
    needed = ("ss_m", "ss_x", "ct_x", "pk_x", "expected_ss")
    if not all(k in vectors for k in needed):
        pytest.skip(
            "Vector file lacks intermediate components (ss_m, ss_x, ct_x, "
            "pk_x). Add them to validate the combiner against the KAT with no "
            "backend dependency."
        )
    got = _combiner(vectors["ss_m"], vectors["ss_x"], vectors["ct_x"], vectors["pk_x"])
    assert got == vectors["expected_ss"], "combiner output != KAT shared secret"
